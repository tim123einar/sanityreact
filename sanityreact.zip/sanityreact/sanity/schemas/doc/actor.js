const actor = {
    title: 'actor',
    name: 'actor',
    type: 'document',
    fields: [
        {
            name: 'name',
            type: 'string',
        },

    ]
}

export default actor;
