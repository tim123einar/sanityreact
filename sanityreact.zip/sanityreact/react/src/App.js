import './App.css';
import Movies from './components/Movies';

function App() {
  return (
    <div className="App">
      <h1>App app app</h1>
      <Movies />
    </div>
  );
}

export default App;
